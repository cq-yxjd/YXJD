from scrapy import cmdline
cmdline.execute('scrapy crawl zhonghua_spider'.split())