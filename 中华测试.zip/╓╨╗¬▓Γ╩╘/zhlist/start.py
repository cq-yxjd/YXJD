from scrapy import cmdline
cmdline.execute('scrapy crawl zhlist_spider'.split())
